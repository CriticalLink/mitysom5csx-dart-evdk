var searchData=
[
  ['gcstring_5fnpos',['GCSTRING_NPOS',['../_g_c_string_8h.html#a90b0760c84efe2dd1076ef11dba699b9',1,'GCString.h']]],
  ['genapi_5fpersistence_5fmagic',['GENAPI_PERSISTENCE_MAGIC',['../_persistence_8h.html#ae787b65935821e67f00e141ee1f13d43',1,'Persistence.h']]]
];
