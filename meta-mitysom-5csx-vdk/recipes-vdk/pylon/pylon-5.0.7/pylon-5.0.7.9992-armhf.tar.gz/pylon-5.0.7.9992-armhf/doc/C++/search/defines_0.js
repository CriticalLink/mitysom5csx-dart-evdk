var searchData=
[
  ['bit_5fper_5fpixel',['BIT_PER_PIXEL',['../_result_8h.html#a7f9223477a75b3cdd2125e6069a15231',1,'Result.h']]]
];
